<?php
include("header.php");
?>
<ul id="demo1">
	<li>
		<img src="images/cover.jpeg" alt=""/>
			<div class="slide-desc">
				<font color="black" size="4"><h3>Good AS </font><br><font color="black" size="10">New</font></h3><br>
				<a href="3c.php"><button class="button buttonblack" ><font face="Antic" size="3" color="black"><span>看 3C</span></button></a>
				<a href="wear.php"><button class="button buttonblack"><font face="Antic" size="3" color="black"><span>看 服飾</span></button></a>
			</div>
	</li>
	<li>
		<img src="images/cover2.jpeg" alt=""/>
			<div class="slide-desc">
				<font color="black" size="4"><h3>Good AS </font><br><font color="black" size="10">New</font></h3><br>
				<a href="3c.php"><button class="button buttonblack" ><font face="Antic" size="3" color="black"><span>看 3C</span></button></a>
				<a href="wear.php"><button class="button buttonblack"><font face="Antic" size="3" color="black"><span>看 服飾</span></button></a>
			</div>
	</li>
</ul>
<?php
include("footer.php");
?>
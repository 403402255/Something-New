<?php
session_start();
//ini_set("display_errors",1);
include("header.php");
include_once 'gpConfig.php';
require_once 'Facebook/autoload.php';
$fb = new \Facebook\Facebook([
    // localhost
    'app_id'     => '790774154431428',
    'app_secret' => '2e92ee177e43ad2654ded6aeeef52098',
    'default_graph_version' => 'v2.8',
]);

$authUrl = $output = "";

$permissions = ['email']; // 其他權限
$helper = $fb->getRedirectLoginHelper();
$URL = 'http://'.$_SERVER['HTTP_HOST'];
$URL = $URL."/shomething/fb_log.php";
$loginUrl = $helper->getLoginUrl($URL, $permissions);

if(isset($_GET['code'])){
    $gClient->authenticate($_GET['code']);
    $_SESSION['token'] = $gClient->getAccessToken();
    exit("<script>window.location.href = 'login.php';</script>");
}

if (isset($_SESSION['token'])) {
    $gClient->setAccessToken($_SESSION['token']);
}

if ($gClient->getAccessToken()) {
	//Get user profile data from google
	$gpUserProfile = $google_oauthV2->userinfo->get();
	
	//Initialize User class
//	$user = new User();
	
	//Insert or update user data to the database
    $gpUserData = array(
        'oauth_provider'=> 'google',
        'oauth_uid'     => $gpUserProfile['id'],
        'first_name'    => $gpUserProfile['given_name'],
        'last_name'     => $gpUserProfile['family_name'],
        'email'         => $gpUserProfile['email'],
        'gender'        => $gpUserProfile['gender'],
        'locale'        => $gpUserProfile['locale'],
        'picture'       => $gpUserProfile['picture'],
        'link'          => $gpUserProfile['link']
    );
//    $userData = $user->checkUser($gpUserData);
    $userData = $gpUserData;
	
	//Storing user data into session
    if( !isset($_SESSION['userData'])){
        $_SESSION['userData'] = $userData;
	exit("<script>window.location.href = 'index.php';</script>");
    }
	
} else {
	$authUrl = $gClient->createAuthUrl();
//	$output = '<a href="'.filter_var($authUrl, FILTER_SANITIZE_URL).'"><img src="images/glogin.png" alt=""/></a>';
}


//Render facebook profile data
if(isset($_SESSION['userData'])){
    $userData = $_SESSION['userData'];
    $last_name = isset($userData["last_name"]) ? $userData["last_name"] : "";
    $output = '<h1>登入資料相關資料 </h1>';
    if ( isset($userData['picture']) ){
        $output .= '<img src="'.$userData['picture'].'" width="300">';
    }
    $output .= '<br/>姓名 : ' . $userData['first_name'].' '.$last_name;
    $output .= '<br/>郵件 : ' . $userData['email'];
    $output .= '<br/> <a href="logout.php">登出</a>'; 
}

?>


<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li>Login</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!-- login -->
	<div class="login">
			<div class="login-form-grids animated wow slideInUp" data-wow-delay=".5s">
				<?php if ( $output == "" ) { ?>
				<form action="login_function.php" method="post">
					<input type="text" placeholder="Account" name="account" required=" " >
					<input type="password" placeholder="Password" name="password" required=" " >
					<input type="submit" value="Login">
				</form>
				<div style="margin-top:20px;">
				<a style="margin-right:10px;" href="<?=$loginUrl?>" class="">Login with Facebook</a>
				/
				<a style="margin-left:10px;" href="<?=$authUrl?>" class="">Login with Google</a>
				</div>
				<?php 
                   } else { 
                    echo $output;
                   }   
                ?>
		</div>
	</div>
<!-- //login -->
<?php
include("footer.php");
?>


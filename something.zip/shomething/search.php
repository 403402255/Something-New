<?php
include("config.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Search results</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
    <?php
    $query = $_GET['query']; 

    $query = htmlspecialchars($query); 
    $query = mysql_real_escape_string($query); 
    //mysql_query("SET NAMES 'utf8'");  
    $sql = "SELECT * FROM products where `p_name` like '%".$query."'%" ;
    $result = mysql_query($sql) or die('MySQL query error');
    while($row = mysql_fetch_array($result)){
     echo $row['p_name']." ";
     echo $row['p_model']."<br>";   
 };
 ?>


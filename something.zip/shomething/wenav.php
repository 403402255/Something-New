<!--//wproductsnav-->
  <div class="products">
   <div class="container">
    <div class="col-md-4 products-left">
     <div class="categories">
      <h2>類別</h2>
      <ul class="cate">
       <li><a href="news.php?<?php echo $bid?>"><i class="fa fa-arrow-right" aria-hidden="true"></i>新聞</a></li>
       <li><a href="accessories.php?brand_name=<?php echo $GLOBALS['name1']?>&brand_id=<?php echo $GLOBALS['bid']?>"><i class='fa fa-arrow-right' aria-hidden='true'></i>飾品</a></li>
       <ul>
        <?php
        $sql = " SELECT distinct gendercategory.gender_name,gendercategory.gender_id FROM gendercategory INNER JOIN products ON gendercategory.gender_id = products.gender_id where brand_id=".$bid;

        $rs_result = $conn->query($sql);
        while($row = $rs_result->fetch_assoc()) {

         ?>
         <li><a href="accessories.php?&brand_name=<?php echo $GLOBALS['name1']?>&brand_id=<?php echo $GLOBALS['bid']?>&gender_id=<?php echo $row["gender_id"]?>"><i class="fa fa-arrow-right" aria-hidden="true"></i><?php echo $row["gender_name"]?></a> </li>
         <?php

        }
        ?></ul>

        <li><a href="outfits.php?&brand_name=<?php echo $GLOBALS['name1']?>&brand_id=<?php echo $GLOBALS['bid']?>&gender_id=<?php echo $row["gender_id"]?>""><i class='fa fa-arrow-right' aria-hidden='true'></i>服飾</a></li>
        <ul>
         <?php
         $sql = " SELECT distinct gendercategory.gender_name FROM gendercategory INNER JOIN products ON gendercategory.gender_id = products.gender_id where brand_id=".$bid;

         $rs_result = $conn->query($sql);
         while($row = $rs_result->fetch_assoc()) {

          ?>
          <li><a href="outfits.php?&brand_name=<?php echo $GLOBALS['name1']?>&brand_id=<?php echo $GLOBALS['bid']?>"><i class="fa fa-arrow-right" aria-hidden="true"></i><?php echo $row["gender_name"]?></a> </li>
          <?php

         }
         ?>
        </ul> 
        <li><a href="shoes.php?&brand_name=<?php echo $GLOBALS['name1']?>&brand_id=<?php echo $GLOBALS['bid']?>"><i class='fa fa-arrow-right' aria-hidden='true'></i>鞋子</a></li>

        <ul>
         <?php
         $sql = " SELECT distinct shoescategory.shoescategory_name FROM shoescategory INNER JOIN products ON shoescategory.shoescategory_id = products.shoescategory_id where brand_id=".$bid;
         $rs_result = $conn->query($sql);
         while($row = $rs_result->fetch_assoc()) {

          ?>

          <li><a href="shoes.php?&brand_name=<?php echo $GLOBALS['name1']?>&brand_id=<?php echo $GLOBALS['bid']?>""><i class="fa fa-arrow-right" aria-hidden="true"></i><?php echo $row["shoescategory_name"]?></a> </li>
          <?php
         }
         ?>
        </ul>
       </ul>
      </div>                   
     </div>
     <div class="col-md-8 products-right">
      <div class="products-right-grid">
       <div class="products-right-grids">
        <div class="sorting-left">
         <select id="country" onchange="change_country(this.value)" class="frm-field required sect">
          <option value="null"><i class="fa fa-arrow-right" aria-hidden="true"></i>最相關</option>
          <option value="null"><i class="fa fa-arrow-right" aria-hidden="true"></i>最高人氣</option> 
          <option value="null"><i class="fa fa-arrow-right" aria-hidden="true"></i>價格由高至低</option>
          <option value="null"><i class="fa fa-arrow-right" aria-hidden="true"></i>價格由低至高</option>
          <option value="null"><i class="fa fa-arrow-right" aria-hidden="true"></i>上架日期</option>
         </select>
        </div>
        <div class="sorting-left">
         <div class="sorting-left">
          <select id="country1" onchange="change_country(this.value)" class="frm-field required sect">
           <option value="null"><i class="fa fa-arrow-right" aria-hidden="true"></i>每頁18項</option>
           <option value="null"><i class="fa fa-arrow-right" aria-hidden="true"></i>每頁36項</option>
          </select>
         </div>
        </div>
        <div class="clearfix"> </div>
       </div>
      </div>
  <!--//wproductsnav-->
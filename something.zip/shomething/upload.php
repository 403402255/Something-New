<form method="post" enctype="multipart/form-data" action="resize.php">
  <input name="file" type="file"><input name="upload" type="submit" value="上傳">
</form>